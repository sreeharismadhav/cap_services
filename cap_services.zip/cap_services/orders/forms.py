from django import forms
from accounts.models import UserAddress


class CartAddForm(forms.Form):
    quantity = forms.IntegerField(min_value=1, max_value=99, initial=1)


class CheckoutForm(forms.Form):
    address = forms.ModelChoiceField(
        queryset=UserAddress.objects.none(),
        widget=forms.RadioSelect,
        required=True
    )
    notes = forms.CharField(widget=forms.Textarea, required=False)
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user:
            self.fields['address'].queryset = UserAddress.objects.filter(user=user)


class CouponForm(forms.Form):
    code = forms.CharField(max_length=50)