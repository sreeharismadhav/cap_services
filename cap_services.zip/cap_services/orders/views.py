from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import Cart, CartItem, Order, OrderItem, Coupon, CouponUsage, CouponType
from store.models import Product, Inventory
from accounts.models import User, UserAddress
from core.utils import generate_order_number, log_activity
from .forms import CartAddForm, CheckoutForm, CouponForm
import json
from core.views import get_base_template


def cart_detail(request):
    if request.session.get('user_id'):
        user = User.objects.get(id=request.session['user_id'])
        cart, created = Cart.objects.get_or_create(user=user)
    else:
        session_id = request.session.session_key
        if not session_id:
            request.session.create()
            session_id = request.session.session_key
        cart, created = Cart.objects.get_or_create(session_id=session_id)
    
    context = {'cart': cart}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'orders/cart.html', context)


@require_POST
def cart_add(request, product_id):
    product = get_object_or_404(Product, id=product_id, status='ACTIVE')
    form = CartAddForm(request.POST)
    
    if form.is_valid():
        quantity = form.cleaned_data['quantity']
        
        # Check stock
        if product.inventory.available < quantity:
            messages.error(request, 'Not enough stock')
            return redirect('store:product_detail', slug=product.slug)
        
        # Get or create cart
        if request.session.get('user_id'):
            user = User.objects.get(id=request.session['user_id'])
            cart, created = Cart.objects.get_or_create(user=user)
        else:
            session_id = request.session.session_key
            if not session_id:
                request.session.create()
                session_id = request.session.session_key
            cart, created = Cart.objects.get_or_create(session_id=session_id)
        
        # Add item to cart
        cart_item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            defaults={'quantity': quantity, 'price': product.current_price}
        )
        
        if not created:
            cart_item.quantity += quantity
            cart_item.save()
        
        # Reserve stock
        product.inventory.reserve(quantity)
        
        messages.success(request, f'{product.name} added to cart')
    
    return redirect('orders:cart_detail')


@require_POST
def cart_remove(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id)
    
    # Release reserved stock
    cart_item.product.inventory.release(cart_item.quantity)
    cart_item.delete()
    
    messages.success(request, 'Item removed from cart')
    return redirect('orders:cart_detail')


@require_POST
def cart_update(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id)
    data = json.loads(request.body)
    quantity = int(data.get('quantity', 1))
    
    if quantity <= 0:
        cart_item.delete()
        return JsonResponse({'status': 'removed'})
    
    # Check stock
    if cart_item.product.inventory.available + cart_item.quantity < quantity:
        return JsonResponse({'status': 'error', 'message': 'Not enough stock'}, status=400)
    
    # Update reserved stock
    diff = quantity - cart_item.quantity
    if diff > 0:
        cart_item.product.inventory.reserve(diff)
    elif diff < 0:
        cart_item.product.inventory.release(-diff)
    
    cart_item.quantity = quantity
    cart_item.save()
    
    return JsonResponse({
        'status': 'success',
        'subtotal': cart_item.subtotal,
        'cart_total': cart_item.cart.total,
        'item_count': cart_item.cart.item_count
    })


def checkout(request):
    if not request.session.get('user_id'):
        return redirect('accounts:login')
    
    user = User.objects.get(id=request.session['user_id'])
    cart = Cart.objects.get(user=user)
    
    if cart.item_count == 0:
        messages.error(request, 'Your cart is empty')
        return redirect('store:product_list')
    
    if request.method == 'POST':
        form = CheckoutForm(request.POST, user=user)
        if form.is_valid():
            # Create order
            order = Order.objects.create(
                user=user,
                shipping_address=form.cleaned_data['address'],
                subtotal=cart.subtotal,
                discount=cart.discount_total,
                total=cart.total,
                notes=form.cleaned_data.get('notes', '')
            )
            
            # Apply coupon if used
            if cart.coupon:
                order.coupon = cart.coupon
                order.discount = cart.discount_total
                order.save()
                
                CouponUsage.objects.create(
                    coupon=cart.coupon,
                    user=user,
                    order=order,
                    discount_amount=cart.discount_total
                )
                cart.coupon.used_count += 1
                cart.coupon.save()
            
            # Create order items
            for cart_item in cart.items.all():
                OrderItem.objects.create(
                    order=order,
                    product=cart_item.product,
                    quantity=cart_item.quantity,
                    price=cart_item.price
                )
                # Deduct stock
                cart_item.product.inventory.deduct(cart_item.quantity)
            
            # Clear cart
            cart.clear()
            
            log_activity(user, f'ORDER_PLACED_{order.order_number}', request=request)
            messages.success(request, f'Order placed successfully! Order #{order.order_number}')
            return redirect('orders:order_detail', order_id=order.id)
    else:
        form = CheckoutForm(user=user)
    
    context = {'cart': cart, 'form': form}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'orders/checkout.html', context)


def order_detail(request, order_id):
    if not request.session.get('user_id'):
        return redirect('accounts:login')
    
    user = User.objects.get(id=request.session['user_id'])
    order = get_object_or_404(Order, id=order_id, user=user)
    
    context = {'order': order}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'orders/order_detail.html', context)


def order_list(request):
    if not request.session.get('user_id'):
        return redirect('accounts:login')
    
    user = User.objects.get(id=request.session['user_id'])
    orders = Order.objects.filter(user=user).order_by('-created_at')
    
    context = {'orders': orders}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'orders/order_list.html', context)


@require_POST
def apply_coupon(request):
    if not request.session.get('user_id'):
        return JsonResponse({'error': 'Login required'}, status=401)
    
    user = User.objects.get(id=request.session['user_id'])
    cart = Cart.objects.get(user=user)
    form = CouponForm(request.POST)
    
    if form.is_valid():
        code = form.cleaned_data['code']
        try:
            coupon = Coupon.objects.get(code=code, is_active=True)
            
            if not coupon.is_valid:
                return JsonResponse({'error': 'Coupon expired or used'})
            
            if cart.subtotal < coupon.minimum_order:
                return JsonResponse({'error': f'Minimum order ₹{coupon.minimum_order} required'})
            
            # Apply coupon
            cart.coupon = coupon
            if coupon.discount_type == CouponType.PERCENT:
                discount = (cart.subtotal * coupon.discount_value / 100)
                if coupon.maximum_discount:
                    discount = min(discount, coupon.maximum_discount)
            else:
                discount = min(coupon.discount_value, cart.subtotal)
            
            cart.coupon_discount = discount
            cart.save()
            
            return JsonResponse({
                'success': True,
                'discount': float(discount),
                'total': float(cart.total)
            })
            
        except Coupon.DoesNotExist:
            return JsonResponse({'error': 'Invalid coupon code'})
    
    return JsonResponse({'error': 'Invalid code'}, status=400)