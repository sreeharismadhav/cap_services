from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.db.models import Count, Q, Avg
from .models import StaffTask, ServiceBooking, StaffTracking, StaffShift, StaffPerformance
from orders.models import Order
from accounts.models import User
from core.decorators import staff_required
from core.utils import log_activity
from .forms import ServiceBookingForm, StaffTaskForm, StaffShiftForm
import json
from core.views import get_base_template


@staff_required
def dashboard(request):
    """Staff dashboard"""
    user = User.objects.get(id=request.session['user_id'])
    
    # Today's tasks
    today = timezone.now().date()
    pending_tasks = StaffTask.objects.filter(
        staff=user,
        status__in=['ASSIGNED', 'ACCEPTED', 'IN_PROGRESS']
    ).order_by('-priority', 'assigned_at')
    
    completed_tasks = StaffTask.objects.filter(
        staff=user,
        status='COMPLETED',
        completed_at__date=today
    ).count()
    
    # Statistics
    stats = {
        'pending': pending_tasks.count(),
        'completed_today': completed_tasks,
        'total_this_week': StaffTask.objects.filter(
            staff=user,
            created_at__week=today.isocalendar()[1]
        ).count(),
        'avg_rating': StaffTask.objects.filter(
            staff=user,
            customer_rating__isnull=False
        ).aggregate(Avg('customer_rating'))['customer_rating__avg'] or 0
    }
    
    context = {
        'user': user,
        'pending_tasks': pending_tasks,
        'stats': stats,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'staff/dashboard.html', context)


@staff_required
def task_list(request):
    """List all tasks for staff"""
    user = User.objects.get(id=request.session['user_id'])
    
    status_filter = request.GET.get('status', 'pending')
    
    if status_filter == 'pending':
        tasks = StaffTask.objects.filter(
            staff=user,
            status__in=['ASSIGNED', 'ACCEPTED', 'IN_PROGRESS']
        )
    elif status_filter == 'completed':
        tasks = StaffTask.objects.filter(staff=user, status='COMPLETED')
    elif status_filter == 'all':
        tasks = StaffTask.objects.filter(staff=user)
    else:
        tasks = StaffTask.objects.filter(staff=user, status=status_filter)
    
    tasks = tasks.order_by('-priority', '-assigned_at')
    
    context = {
        'tasks': tasks,
        'current_filter': status_filter,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'staff/task_list.html', context)


@staff_required
def task_detail(request, task_id):
    """Task details"""
    user = User.objects.get(id=request.session['user_id'])
    task = get_object_or_404(StaffTask, id=task_id, staff=user)
    
    context = {'task': task}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'staff/task_detail.html', context)


@require_POST
@staff_required
def task_accept(request, task_id):
    """Accept a task"""
    user = User.objects.get(id=request.session['user_id'])
    task = get_object_or_404(StaffTask, id=task_id, staff=user)
    
    task.accept()
    log_activity(user, f'TASK_ACCEPTED_{task.id}', request=request)
    messages.success(request, 'Task accepted')
    
    return redirect('staff:task_detail', task_id=task.id)


@require_POST
@staff_required
def task_start(request, task_id):
    """Start a task"""
    user = User.objects.get(id=request.session['user_id'])
    task = get_object_or_404(StaffTask, id=task_id, staff=user)
    
    task.start()
    log_activity(user, f'TASK_STARTED_{task.id}', request=request)
    messages.success(request, 'Task started')
    
    return redirect('staff:task_detail', task_id=task.id)


@require_POST
@staff_required
def task_complete(request, task_id):
    """Complete a task"""
    user = User.objects.get(id=request.session['user_id'])
    task = get_object_or_404(StaffTask, id=task_id, staff=user)
    
    notes = request.POST.get('notes', '')
    task.complete(notes)
    
    # Update performance metrics
    performance, created = StaffPerformance.objects.get_or_create(
        staff=user,
        period_start=timezone.now().replace(day=1),
        period_end=timezone.now().replace(day=28)  # Simplified
    )
    performance.tasks_completed += 1
    performance.save()
    
    log_activity(user, f'TASK_COMPLETED_{task.id}', request=request)
    messages.success(request, 'Task completed')
    
    return redirect('staff:task_list')


@staff_required
def services_list(request):
    """List service bookings assigned to staff"""
    user = User.objects.get(id=request.session['user_id'])
    
    services = ServiceBooking.objects.filter(
        assigned_staff=user
    ).order_by('-created_at')
    
    context = {'services': services}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'staff/services_list.html', context)


@staff_required
def service_detail(request, service_id):
    """Service booking details"""
    user = User.objects.get(id=request.session['user_id'])
    service = get_object_or_404(ServiceBooking, id=service_id, assigned_staff=user)
    
    context = {'service': service}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'staff/service_detail.html', context)


@require_POST
@staff_required
def update_location(request):
    """Update staff location"""
    user = User.objects.get(id=request.session['user_id'])
    data = json.loads(request.body)
    
    latitude = data.get('latitude')
    longitude = data.get('longitude')
    
    if latitude and longitude:
        StaffTracking.objects.create(
            staff=user,
            latitude=latitude,
            longitude=longitude
        )
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error'}, status=400)


@staff_required
def shift_view(request):
    """View staff shift"""
    user = User.objects.get(id=request.session['user_id'])
    today = timezone.now().date()
    
    shift = StaffShift.objects.filter(
        staff=user,
        shift_date=today
    ).first()
    
    context = {'shift': shift}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'staff/shift.html', context)


@require_POST
@staff_required
def clock_in(request):
    """Clock in for shift"""
    user = User.objects.get(id=request.session['user_id'])
    today = timezone.now().date()
    
    shift = StaffShift.objects.filter(
        staff=user,
        shift_date=today
    ).first()
    
    if shift:
        shift.clock_in_now()
        messages.success(request, f'Clocked in at {timezone.now().strftime("%H:%M")}')
    else:
        messages.error(request, 'No shift scheduled for today')
    
    return redirect('staff:shift')


@require_POST
@staff_required
def clock_out(request):
    """Clock out from shift"""
    user = User.objects.get(id=request.session['user_id'])
    today = timezone.now().date()
    
    shift = StaffShift.objects.filter(
        staff=user,
        shift_date=today,
        clock_in__isnull=False,
        clock_out__isnull=True
    ).first()
    
    if shift:
        shift.clock_out_now()
        messages.success(request, f'Clocked out at {timezone.now().strftime("%H:%M")}')
    else:
        messages.error(request, 'No active shift found')
    
    return redirect('staff:shift')


@staff_required
def performance_view(request):
    """Staff performance metrics"""
    user = User.objects.get(id=request.session['user_id'])
    
    performances = StaffPerformance.objects.filter(
        staff=user
    ).order_by('-period_start')[:12]
    
    context = {'performances': performances}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'staff/performance.html', context)