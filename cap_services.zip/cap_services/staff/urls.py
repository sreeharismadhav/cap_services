from django.urls import path
from . import views

app_name = 'staff'

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('tasks/', views.task_list, name='task_list'),
    path('task/<int:task_id>/', views.task_detail, name='task_detail'),
    path('task/<int:task_id>/accept/', views.task_accept, name='task_accept'),
    path('task/<int:task_id>/start/', views.task_start, name='task_start'),
    path('task/<int:task_id>/complete/', views.task_complete, name='task_complete'),
    path('services/', views.services_list, name='services_list'),
    path('service/<int:service_id>/', views.service_detail, name='service_detail'),
    path('update-location/', views.update_location, name='update_location'),
    path('shift/', views.shift_view, name='shift'),
    path('clock-in/', views.clock_in, name='clock_in'),
    path('clock-out/', views.clock_out, name='clock_out'),
    path('performance/', views.performance_view, name='performance'),
]