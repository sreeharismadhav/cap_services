from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.db.models import Sum, Count, Q, F
from django.db.models.functions import TruncMonth
from core.decorators import admin_required
from core.utils import log_activity
from accounts.models import User, UserAddress
from store.models import Product, Category, Inventory, InventoryHistory
from orders.models import Order, OrderItem, Coupon, CouponUsage, CouponType
from staff.models import StaffTask, ServiceBooking, StaffPerformance
from .models import AdminAlert, SystemReport, Announcement
from .forms import AnnouncementForm
from core.views import get_base_template
import json
from datetime import datetime, timedelta


@admin_required
def dashboard(request):
    """Main admin dashboard"""
    user = User.objects.get(id=request.session['user_id'])
    
    # Get date range for today
    today = timezone.now().date()
    start_of_day = timezone.make_aware(datetime.combine(today, datetime.min.time()))
    end_of_day = timezone.make_aware(datetime.combine(today, datetime.max.time()))
    
    # Statistics
    stats = {
        'total_customers': User.objects.filter(role='CUSTOMER').count(),
        'total_staff': User.objects.filter(role='STAFF').count(),
        'total_products': Product.objects.filter(is_active=True).count(),
        'total_orders': Order.objects.count(),
        'pending_orders': Order.objects.filter(status__in=['PLACED', 'CONFIRMED']).count(),
        'today_orders': Order.objects.filter(created_at__date=today).count(),
        'today_revenue': Order.objects.filter(
            created_at__date=today,
            payment_status='PAID'
        ).aggregate(total=Sum('total'))['total'] or 0,
        'total_revenue': Order.objects.filter(payment_status='PAID').aggregate(total=Sum('total'))['total'] or 0,
        'low_stock': Inventory.objects.filter(quantity__lte=F('low_stock_threshold')).count(),
        'pending_services': ServiceBooking.objects.filter(status='REQUESTED').count(),
    }
    
    # Recent orders
    recent_orders = Order.objects.select_related('user').order_by('-created_at')[:10]
    
    # Recent staff tasks
    recent_tasks = StaffTask.objects.select_related('staff').order_by('-assigned_at')[:10]
    
    context = {
        'user': user,
        'stats': stats,
        'recent_orders': recent_orders,
        'recent_tasks': recent_tasks,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/dashboard.html', context)


@admin_required
def users_list(request):
    """List all users"""
    users = User.objects.all().order_by('-created_at')
    
    role_filter = request.GET.get('role')
    if role_filter:
        users = users.filter(role=role_filter)
    
    search = request.GET.get('search')
    if search:
        users = users.filter(
            Q(email__icontains=search) |
            Q(first_name__icontains=search) |
            Q(last_name__icontains=search) |
            Q(phone__icontains=search)
        )
    
    context = {
        'users': users,
        'role_filter': role_filter,
        'search': search,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/users.html', context)


@admin_required
def user_detail(request, user_id):
    """View user details"""
    user = get_object_or_404(User, id=user_id)
    addresses = UserAddress.objects.filter(user=user)
    orders = Order.objects.filter(user=user).order_by('-created_at')[:10]
    services = ServiceBooking.objects.filter(user=user).order_by('-created_at')[:10]
    
    context = {
        'user': user,
        'addresses': addresses,
        'orders': orders,
        'services': services,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/user_detail.html', context)


@admin_required
def staff_list(request):
    """List all staff members"""
    staff = User.objects.filter(role='STAFF').order_by('-created_at')
    
    context = {'staff': staff}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/staff.html', context)


@admin_required
def staff_detail(request, staff_id):
    """View staff details and performance"""
    staff = get_object_or_404(User, id=staff_id, role='STAFF')
    
    tasks = StaffTask.objects.filter(staff=staff).order_by('-assigned_at')[:20]
    performance = StaffPerformance.objects.filter(staff=staff).order_by('-period_start')[:6]
    
    context = {
        'staff': staff,
        'tasks': tasks,
        'performance': performance,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/staff_detail.html', context)


@admin_required
def products_list(request):
    """List all products"""
    products = Product.objects.all().order_by('-created_at')
    
    category_filter = request.GET.get('category')
    if category_filter:
        products = products.filter(category_id=category_filter)
    
    status_filter = request.GET.get('status')
    if status_filter:
        products = products.filter(status=status_filter)
    
    search = request.GET.get('search')
    if search:
        products = products.filter(name__icontains=search)
    
    categories = Category.objects.filter(is_active=True)
    
    context = {
        'products': products,
        'categories': categories,
        'category_filter': category_filter,
        'status_filter': status_filter,
        'search': search,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/products.html', context)


@admin_required
def orders_list(request):
    """List all orders"""
    orders = Order.objects.all().order_by('-created_at')
    
    status_filter = request.GET.get('status')
    if status_filter:
        orders = orders.filter(status=status_filter)
    
    payment_filter = request.GET.get('payment')
    if payment_filter:
        orders = orders.filter(payment_status=payment_filter)
    
    search = request.GET.get('search')
    if search:
        orders = orders.filter(order_number__icontains=search)
    
    context = {
        'orders': orders,
        'status_filter': status_filter,
        'payment_filter': payment_filter,
        'search': search,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/orders.html', context)


@admin_required
def order_detail(request, order_id):
    """View order details"""
    order = get_object_or_404(Order, id=order_id)
    
    context = {'order': order}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/order_detail.html', context)


@require_POST
@admin_required
def update_order_status(request, order_id):
    """Update order status"""
    order = get_object_or_404(Order, id=order_id)
    new_status = request.POST.get('status')
    notes = request.POST.get('notes', '')
    
    if new_status:
        user = User.objects.get(id=request.session['user_id'])
        order.update_status(new_status, user, notes)
        log_activity(user, f'ADMIN_UPDATE_ORDER_STATUS_{order.order_number}', request=request)
        messages.success(request, f'Order status updated to {new_status}')
    
    return redirect('admin_panel:order_detail', order_id=order.id)


@admin_required
def services_list(request):
    """List all service bookings"""
    services = ServiceBooking.objects.all().order_by('-created_at')
    
    status_filter = request.GET.get('status')
    if status_filter:
        services = services.filter(status=status_filter)
    
    context = {
        'services': services,
        'status_filter': status_filter,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/services.html', context)


@admin_required
def service_detail(request, service_id):
    """View service booking details"""
    service = get_object_or_404(ServiceBooking, id=service_id)
    
    context = {'service': service}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/service_detail.html', context)


@require_POST
@admin_required
def assign_staff(request, service_id):
    """Assign staff to service"""
    service = get_object_or_404(ServiceBooking, id=service_id)
    staff_id = request.POST.get('staff_id')
    
    if staff_id:
        staff = get_object_or_404(User, id=staff_id, role='STAFF')
        service.assigned_staff = staff
        service.status = 'ASSIGNED'
        service.save()
        
        # Create staff task
        StaffTask.objects.create(
            staff=staff,
            task_type='SERVICE',
            service=service,
            assigned_by=User.objects.get(id=request.session['user_id'])
        )
        
        messages.success(request, f'Staff {staff.email} assigned')
    
    return redirect('admin_panel:service_detail', service_id=service.id)


@admin_required
def inventory_list(request):
    """List inventory with low stock alerts"""
    inventory = Inventory.objects.select_related('product').all()
    
    low_stock = request.GET.get('low_stock')
    if low_stock:
        inventory = inventory.filter(quantity__lte=F('low_stock_threshold'))
    
    context = {
        'inventory': inventory,
        'low_stock_filter': low_stock,
    }
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/inventory.html', context)


@require_POST
@admin_required
def update_inventory(request, inventory_id):
    """Update inventory quantity"""
    inventory = get_object_or_404(Inventory, id=inventory_id)
    quantity = int(request.POST.get('quantity', 0))
    reason = request.POST.get('reason', 'Admin adjustment')
    
    from store.models import InventoryHistory
    from core.enums import InventoryChangeType
    
    old_quantity = inventory.quantity
    inventory.quantity = quantity
    inventory.save()
    
    InventoryHistory.objects.create(
        inventory=inventory,
        old_quantity=old_quantity,
        new_quantity=quantity,
        change_type=InventoryChangeType.ADJUSTMENT,
        changed_by=User.objects.get(id=request.session['user_id']),
        notes=reason
    )
    
    messages.success(request, 'Inventory updated')
    return redirect('admin_panel:inventory_list')


@admin_required
def reports_view(request):
    """View reports dashboard"""
    context = {}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/reports.html', context)


@admin_required
def generate_report(request):
    """Generate a report"""
    if request.method == 'POST':
        report_type = request.POST.get('report_type')
        period_start = request.POST.get('period_start')
        period_end = request.POST.get('period_end')
        
        # Generate report data based on type
        data = {}
        
        if report_type == 'SALES':
            orders = Order.objects.filter(
                created_at__date__gte=period_start,
                created_at__date__lte=period_end
            )
            data = {
                'total_orders': orders.count(),
                'total_revenue': orders.aggregate(Sum('total'))['total__sum'] or 0,
                'orders_by_status': orders.values('status').annotate(count=Count('id')),
            }
        
        elif report_type == 'INVENTORY':
            data = {
                'total_products': Product.objects.count(),
                'low_stock': Inventory.objects.filter(quantity__lte=F('low_stock_threshold')).count(),
                'out_of_stock': Inventory.objects.filter(quantity=0).count(),
            }
        
        elif report_type == 'STAFF':
            data = {
                'total_staff': User.objects.filter(role='STAFF').count(),
                'tasks_completed': StaffTask.objects.filter(
                    status='COMPLETED',
                    completed_at__date__gte=period_start,
                    completed_at__date__lte=period_end
                ).count(),
            }
        
        user = User.objects.get(id=request.session['user_id'])
        
        SystemReport.objects.create(
            report_type=report_type,
            title=f"{report_type} Report - {period_start} to {period_end}",
            data=data,
            generated_by=user,
            period_start=period_start,
            period_end=period_end
        )
        
        messages.success(request, 'Report generated')
        return redirect('admin_panel:reports')
    
    return redirect('admin_panel:reports')


@admin_required
def announcements(request):
    """Manage announcements"""
    announcements = Announcement.objects.all().order_by('-created_at')
    
    context = {'announcements': announcements}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/announcements.html', context)


@admin_required
def create_announcement(request):
    """Create new announcement"""
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        announcement_type = request.POST.get('announcement_type')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        target_roles = request.POST.getlist('target_roles')
        
        Announcement.objects.create(
            title=title,
            content=content,
            announcement_type=announcement_type,
            start_date=start_date,
            end_date=end_date,
            target_roles=target_roles
        )
        
        messages.success(request, 'Announcement created')
        return redirect('admin_panel:announcements')
    context = {}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/create_announcement.html',context)


@admin_required
def delete_announcement(request, announcement_id):
    """Delete announcement"""
    announcement = get_object_or_404(Announcement, id=announcement_id)
    announcement.delete()
    messages.success(request, 'Announcement deleted')
    return redirect('admin_panel:announcements')


@admin_required
def system_settings(request):
    """System settings"""
    from core.models import SystemConfig
    
    configs = SystemConfig.objects.all()
    
    if request.method == 'POST':
        for key, value in request.POST.items():
            if key.startswith('config_'):
                config_key = key.replace('config_', '')
                config, created = SystemConfig.objects.get_or_create(config_key=config_key)
                config.config_value = value
                config.save()
        messages.success(request, 'Settings saved')
    
    context = {'configs': configs}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/settings.html', context)


@admin_required
def alerts(request):
    """View system alerts"""
    alerts = AdminAlert.objects.all().order_by('-created_at')
    
    if request.method == 'POST':
        alert_id = request.POST.get('mark_read')
        if alert_id:
            alert = get_object_or_404(AdminAlert, id=alert_id)
            user = User.objects.get(id=request.session['user_id'])
            alert.read_by.add(user)
            messages.success(request, 'Alert marked as read')
    
    context = {'alerts': alerts}
    context['base_template'] = get_base_template(request.session.get('user_role'))
    return render(request, 'admin_panel/alerts.html', context)