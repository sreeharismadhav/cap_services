from django.urls import path
from . import views

app_name = 'admin_panel'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # Users
    path('users/', views.users_list, name='users'),
    path('users/<int:user_id>/', views.user_detail, name='user_detail'),
    path('staff/', views.staff_list, name='staff'),
    path('staff/<int:staff_id>/', views.staff_detail, name='staff_detail'),
    
    # Products
    path('products/', views.products_list, name='products'),
    
    # Orders
    path('orders/', views.orders_list, name='orders'),
    path('orders/<int:order_id>/', views.order_detail, name='order_detail'),
    path('orders/<int:order_id>/update-status/', views.update_order_status, name='update_order_status'),
    
    # Services
    path('services/', views.services_list, name='services'),
    path('services/<int:service_id>/', views.service_detail, name='service_detail'),
    path('services/<int:service_id>/assign-staff/', views.assign_staff, name='assign_staff'),
    
    # Inventory
    path('inventory/', views.inventory_list, name='inventory'),
    path('inventory/<int:inventory_id>/update/', views.update_inventory, name='update_inventory'),
    
    # Reports
    path('reports/', views.reports_view, name='reports'),
    path('reports/generate/', views.generate_report, name='generate_report'),
    
    # Announcements
    path('announcements/', views.announcements, name='announcements'),
    path('announcements/create/', views.create_announcement, name='create_announcement'),
    path('announcements/delete/<int:announcement_id>/', views.delete_announcement, name='delete_announcement'),
    
    # Settings
    path('settings/', views.system_settings, name='settings'),
    path('alerts/', views.alerts, name='alerts'),
]